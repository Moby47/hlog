//edit course

$(".settings_btn").click(function(e){

        e.preventDefault();

        let formData = $('.settings').serialize();
        
        $.ajax({
            url: 'ajax/ajax_request_course_update.php',
            type: 'post',
            data: formData,
           
            success: function(data){
            
                $("#msg").html(data);
               
            }//success end
        });
     

});



//admin add course

$(".add_btn").click(function(e){

        e.preventDefault();

       let formData = $('.add_course_form').serialize();
        
        $.ajax({
            url: 'ajax/ajax_add_course.php',
            type: 'post',
            data: formData,

            beforeSend:function(){
            $(".load").show();
            },

             complete:function(){
            $(".load").hide();
            },

            success: function(data){
            $(".cos").html(data);
            
            }//success end
        });
     

});