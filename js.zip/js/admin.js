//load users and uploads
$(document).ready(function(){
 $(".count1").load("ajax/ajax_count_instructors.php");
 $(".count2").load("ajax/ajax_count_students.php");
});




//validate users and paginated

$(document).ready(function(){
changePagination('0');	
});
function changePagination(pageId){
     
     var dataString = 'pageId='+ pageId;
     $.ajax({
           type: "POST",
           url: "ajax/ajax_validate_users.php",
           data: dataString,
           cache: false,
           success: function(result){
           
                 $("#validate").html(result);
           }
      });
}




