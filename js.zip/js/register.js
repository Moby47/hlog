//ajax reg 

$(".go").click(function(e){

        e.preventDefault();

        let formData = $('.reg_form').serialize();
        
        $.ajax({
            url: 'ajax/ajax_reg.php',
            type: 'post',
            data: formData,

             beforeSend:function(){
            $(".load").addClass("fa fa-refresh fa-spin");
            },

             complete:function(){
            $(".load").removeClass("fa fa-refresh fa-spin");
            },

            success: function(data){
            $("#err_reg").html(data);
           $(document).scrollTop(0);
           
            }//success end
        });


});



//validation student reg form check numeric
//regex to get only letters ,fname
$(".v_fname").on("input change keyup blur paste", function(){
let v=$(".v_fname").val();
let exp=/^[a-zA-Z]*$/;

if(exp.test($(".v_fname").val())){
$(".e_fname").html("");
$(this).css("border-color","inherit");
}else{
$(".e_fname").html(v+" is not a valid name..");
$(".e_fname").css("color","red");
$(this).css("border-color","red");
}
})

//regex to get only letters ,lname
$(".v_lname").on("input change keyup blur paste", function(){
let v=$(".v_lname").val();
let exp=/^[a-zA-Z]*$/;

if(exp.test($(".v_lname").val())){
$(".e_lname").html("");
$(this).css("border-color","inherit");
}else{
$(".e_lname").html(v+" is not a valid name..");
$(".e_lname").css("color","red");
$(this).css("border-color","red");
}
})


//password strenght
$(".pass").on("input change keyup blur paste", function(){
let pv=$(".pass").val();

if($.trim(pv).length<1){
$("i").html("Enter a Password");
$("i").css("color","black");
}else if($.trim(pv).length<5){
$("i").html("Password Strenght: Weak");
$("i").css("color","red");
}else if($.trim(pv).length<7){
$("i").html("Password Strenght: Normal");
$("i").css("color","orange");
}else if($.trim(pv).length<10){
$("i").html("Password Strenght: Strong");
$("i").css("color","#b4dcb4");
}else{
$("i").html("Password Strenght: Very Strong");
$("i").css("color","lime");
}

})