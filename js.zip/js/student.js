//view uploads for stu
$(document).ready(function(){
    $(".count_up").load("ajax/ajax_count_uploads.php");
   
})



//downloads view and pagination

$(document).ready(function(){
changePagination('0');	
});
function changePagination(pageId){
     
     var dataString = 'pageId='+ pageId;
     $.ajax({
           type: "POST",
           url: "ajax/ajax_student_view_downloads.php",
           data: dataString,
           cache: false,
           success: function(result){
           
                 $("#pageData").html(result);
           }
      });
}




//search the files
$(function(){

	$(".search").on("keyup", function(){

    let element=$(this);
    let value=element.val();
    let info='id=' + value;
    //alert(info);
//if (confirm("Delete This User?")){

 $.ajax({
            url: 'ajax/ajax_student_search.php',
            type: 'post',
            data: info,

           

            success: function(data){
            $(".display_dd").html(data);
            }//success end
        });//ajax end



//}//if confirm end

})//del click end

})//func end
