//user ajax sign in

$(".user_signin_btn").click(function(e){

        e.preventDefault();

        let formData = $('.user_login_form').serialize();
        
        $.ajax({
            url: 'ajax/ajax_user_login.php',
            type: 'post',
            data: formData,
           
             beforeSend:function(){
            $(".load").addClass("fa fa-refresh fa-spin");
            },

             complete:function(){
            $(".load").removeClass("fa fa-refresh fa-spin");
            },
        
            success: function(data){
            
            if(data==="instructor"){
             window.location.href="instructor.php";
            }else if(data==="student"){
             window.location.href="student.php";
            }else if(data==="admin"){
             window.location.href="admin.php";
             }else{
               $("#err").show();
                $("#err").html(data);
                }//if end
            }//success end
        });
     

});