
//search the files
$(function(){

	$(".search").on("keyup", function(){

    let element=$(this);
    let value=element.val();
    let info='id=' + value;
    //alert(info);
//if (confirm("Delete This User?")){

 $.ajax({
            url: 'ajax/ajax_instructor_search.php',
            type: 'post',
            data: info,


            success: function(data){
            $(".display_dd").html(data);
            }//success end
        });//ajax end



//}//if confirm end

})//del click end

})//func end




//upload file


$(document).ready(function (e) {
	$("#form").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "ajax/ajax_upload.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
            
            
             beforeSend:function(){
            $(".load").addClass("fa fa-refresh fa-spin");
            },

             complete:function(){
            $(".load").removeClass("fa fa-refresh fa-spin");
            },
            

			success: function(data)
		    {
				if(data=='invalid')
				{
					// invalid file format.
                    $("#err").html("<span class='alert alert-warning'>Choose A valid File</span>").fadeIn();
                    $("#preview").hide("fade");
				}
				else
				{
					// view uploaded file.
                    $("#preview").html(data).fadeIn();
                    $("#err").hide("fade");
                    $("#form")[0].reset();	
                    $(".count_up").load("ajax/ajax_instructor_count_uploads.php");
                    $("#pageData").load("ajax/ajax_instructor_uploaded.php");
                    
				}
		    },
		  	error: function(e) 
	    	{
				$("#err").html(e).fadeIn();
	    	} 	        
	   });
	}));
});



//files view and pagination

$(document).ready(function(){
changePagination('0');	
});
function changePagination(pageId){
     
     var dataString = 'pageId='+ pageId;
     $.ajax({
           type: "POST",
           url: "ajax/ajax_instructor_uploaded.php",
           data: dataString,
           cache: false,
           success: function(result){
           
                 $("#pageData").html(result);
           }
      });
}


//count uploads
$(document).ready(function(){
    $(".count_up").load("ajax/ajax_instructor_count_uploads.php");
   
})