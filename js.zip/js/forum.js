
//initial comment load
$("#message").load("ajax/ajax_load_comment.php");

//comment refresh
$(document).ready(function(){
	
    setInterval(function(){
     $("#message").load("ajax/ajax_load_comment.php");
},3000);

})


//send comment

$(".send").click(function(e){

 e.preventDefault();

        let formData = $('.comment_send_div').serialize();
        
        $.ajax({
            url: 'ajax/ajax_forum_send_comment.php',
            type: 'post',
            data: formData,
            success: function(data){
e.preventDefault();
                $("#message").load("ajax/ajax_load_comment.php");
            $(".report").html(data); 
               $(".area").val('');
            
            }//success end
        });

})







//search comments
$(function(){

	$(".searchbox").on("keyup", function(){

    let element=$(this);
    let value=element.val();
    let info='id=' + value;
    //alert(info);
//if (confirm("Delete This User?")){

 $.ajax({
            url: 'ajax/ajax_forum_search.php',
            type: 'post',
            data: info,

            beforeSend:function(){
            $(".load").show();
            },

             complete:function(){
            $(".load").hide();
            },

            success: function(data){
            $(".result").html(data);
            }//success end
        });//ajax end


//}//if confirm end

})//del click end

})//func end






//send message with enter key


$('.text').keypress(function(e){

	var keycode = (event.keyCode ? event.keyCode : event.which);
	if(keycode == '13'){
        
        e.preventDefault();

        let formData = $('.comment_send_div').serialize();
        
        $.ajax({
            url: 'ajax/ajax_forum_send_comment.php',
            type: 'post',
            data: formData,
            success: function(data){

                $("#message").load("ajax/ajax_load_comment.php");

            $(".report").html(data); 
      $(".area").val('');
            
            }//success end
        });

	}

});

