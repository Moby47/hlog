<?php
require("../includes/downloads.php");
session_start();

//initialise array
$error=array();
$expname="/[a-zA-Z]+$/";

if(preg_match($expname,$_POST['stu_fname'])){
  $stu_fname=mysqli_real_escape_string($link, trim($_POST['stu_fname']));
}else{
$error[]="Insert a Valid Firstname<br>";
}

if(preg_match($expname,$_POST['stu_lname'])){
  $stu_lname=mysqli_real_escape_string($link, trim($_POST['stu_lname']));
}else{
$error[]="Insert a Valid Lastname<br>";
}

if (!filter_var($_POST['stu_email'], FILTER_VALIDATE_EMAIL)) {
    $error[]="Insert A Valid Email Address<br>";
}else{
$stu_mail=mysqli_real_escape_string($link, trim($_POST['stu_email']));
}


if(empty($_POST['stu_password'])){
$error[]="Insert a Password<br>";
}else{
$stu_pass=mysqli_real_escape_string($link, trim($_POST['stu_password']));
}

if(empty($_POST['role'])){
$error[]="Select a Role<br>";
}else{
$req_role=mysqli_real_escape_string($link, trim($_POST['role']));
}

$stu_course=mysqli_real_escape_string($link, trim($_POST['stu_course']));
$stu_course2=mysqli_real_escape_string($link, trim($_POST['stu_course2']));
$stu_course3=mysqli_real_escape_string($link, trim($_POST['stu_course3']));

if(empty($_POST['stu_course2'])){
	$stu_course2="N/A";
}

if(empty($stu_course3)){
	$stu_course3="N/A";
}

if(empty($_POST['stu_course'])){
$error[]="Course 1 Must Be Selected<br>";
}else if ($stu_course==$stu_course2 || $stu_course==$stu_course3){
	$error[]="Same Course Selected Twice<br>";
}

if(!empty($_POST['stu_course2']) AND $stu_course2==$stu_course3){
$error[]="Same Course Selected Twice<br>";
}

$unv="unverified";

if(!empty($error)){

foreach ($error as $err){
    echo "<div class='alert alert-warning text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						   $err
						</div>";
}
  
}else{

	$check="SELECT * FROM users WHERE email='$stu_mail'"; 
	$q=mysqli_query($link,$check);
	if(mysqli_num_rows($q)==1){
		echo "<div class='alert alert-danger text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						   User Already Exists!
						</div>";
	}else{

$send="INSERT INTO users (`fname`, `lname`, `email`, `password`, `course`, `course2`, `course3`, `status`, `verification`, `date_reg`) 
VALUES ('$stu_fname', '$stu_lname', '$stu_mail', '$stu_pass', '$stu_course', '$stu_course2', '$stu_course3', '$req_role', '$unv', now())";

$query=mysqli_query($link,$send);

if($query){

echo "<div class='alert alert-success text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						   Registration Successful! <br> Await Admin's Verification...<a href='index.php' class='to_register hiit_color_icon'> Back </a>
						</div>";

}else{

  echo "<div class='alert alert-success text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						   Registration Failed! Verify Input
						</div>";    
}

	}//chek exists




}//err check end



?>