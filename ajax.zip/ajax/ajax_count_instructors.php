<?php
require("../includes/downloads.php");
session_start();

$q="SELECT status FROM users WHERE status='instructor' AND verification!='unverified'";

$qq=mysqli_query($link,$q);

$num=mysqli_num_rows($qq);

echo "$num";

?>