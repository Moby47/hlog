<?php
require("../includes/downloads.php");
session_start();


//initialise array
$error=array();

$id=$_POST['idd'];
$stu_course=mysqli_real_escape_string($link, trim($_POST['stu_course']));
$stu_course2=mysqli_real_escape_string($link, trim($_POST['stu_course2']));
$stu_course3=mysqli_real_escape_string($link, trim($_POST['stu_course3']));

if(empty($_POST['stu_course2'])){
	$stu_course2="N/A";
}

if(empty($stu_course3)){
	$stu_course3="N/A";
}

if(empty($_POST['stu_course'])){
$error[]="Course 1 Must Be Selected<br>";
}else if ($stu_course==$stu_course2 || $stu_course==$stu_course3){
	$error[]="Same Course Selected Twice<br>";
}



if(!empty($_POST['stu_course2']) AND $stu_course2==$stu_course3){
$error[]="Same Course Selected Twice<br>";
}

if(!empty($error)){

foreach ($error as $err){
    echo "<div class='alert alert-warning text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						   $err
						</div>";
}
  
}else{
	
	//update rec
 $query="UPDATE users SET course='$stu_course', course2='$stu_course2', course3='$stu_course3', verification='unverified' WHERE user_id='$id'";
 $r=mysqli_query($link,$query);

	if($r){
echo "<div class='alert alert-success text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						   Request Sent!
						</div>";

}else{
echo "<div class='alert alert-success text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						  Not Sent!
						</div>";
    }//if end $r
}

?>