<?php

require("../includes/downloads.php");
session_start();

$error="";
//if course empty
if(!empty($_POST['course'])){

   $course=mysqli_real_escape_string($link, trim($_POST['course']));
}else{
    $error="Please Insert email";
}


if(!empty($error)){
  echo "<div class='alert alert-warning text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						   Insert a Course
						</div>";

}else{

	$check="SELECT * FROM misc WHERE courses='$course'"; 
	$q=mysqli_query($link,$check);
	if(mysqli_num_rows($q)==1){
		echo "<div class='alert alert-danger text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						   User Already Exists!
						</div>";
	

}else{

$send="INSERT INTO misc (courses) 
VALUES ('$course')";

$query=mysqli_query($link,$send);

if($query){

echo  "<div class='alert alert-success text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						   Course Added Successful!
						</div>";
}else{

  echo "<div class='alert alert-danger text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						   Failed To Add Course
						</div>";    
}

}//empty if end
}
?>