<?php
require("../includes/downloads.php");
session_start();


$course=$_SESSION['course'];
$course2=$_SESSION['course2'];
$course3=$_SESSION['course3'];
$fname=$_SESSION['fname'];





$query="SELECT file_name FROM uploads WHERE instructor='$fname' AND (course='$course'  OR course='$course2' OR course='$course3')";
$res    = mysqli_query($link,$query);
$count  = mysqli_num_rows($res);
$page = (int) (!isset($_REQUEST['pageId']) ? 1 :$_REQUEST['pageId']);
$page = ($page == 0 ? 1 : $page);
$recordsPerPage = 3;
$start = ($page-1) * $recordsPerPage;
$adjacents = "2";

$prev = $page - 1;
$next = $page + 1;
$lastpage = ceil($count/$recordsPerPage);
$lpm1 = $lastpage - 1;   
$pagination = "";
if($lastpage > 1)
    {   
        $pagination .= "<ul class='pagination pagination-md'>";
        if ($page > 1)
            $pagination.= "<li><a href=\"#Page=".($prev)."\" onClick='changePagination(".($prev).");'>&laquo; Previous&nbsp;&nbsp;</a></li>";
        else
            $pagination.= "<li><span class='disabled'>&laquo; Previous&nbsp;&nbsp;</span></li>";   
        if ($lastpage < 7 + ($adjacents * 2))
        {   
            for ($counter = 1; $counter <= $lastpage; $counter++)
            {
                if ($counter == $page)
                    $pagination.= "<li><span class='current'>$counter</span></li>";
                else
                    $pagination.= "<li><a href=\"#Page=".($counter)."\" onClick='changePagination(".($counter).");'>$counter</a></li>";     

            }
        }   

        elseif($lastpage > 5 + ($adjacents * 2))
        {
            if($page < 1 + ($adjacents * 2))
            {
                for($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
                {
                    if($counter == $page)
                        $pagination.= "<li><span class='current'>$counter</span></li>";
                    else
                        $pagination.= "<li><a href=\"#Page=".($counter)."\" onClick='changePagination(".($counter).");'>$counter</a></li>";     
                }
                $pagination.= "...";
                $pagination.= "<li><a href=\"#Page=".($lpm1)."\" onClick='changePagination(".($lpm1).");'>$lpm1</a></li>";
                $pagination.= "<li><a href=\"#Page=".($lastpage)."\" onClick='changePagination(".($lastpage).");'>$lastpage</a></li>";   

           }
           elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
           {
               $pagination.= "<li><a href=\"#Page=\"1\"\" onClick='changePagination(1);'>1</a></li>";
               $pagination.= "<li><a href=\"#Page=\"2\"\" onClick='changePagination(2);'>2</a></li>";
               $pagination.= "...";
               for($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
               {
                   if($counter == $page)
                       $pagination.= "<li><span class='current'>$counter</span></li>";
                   else
                       $pagination.= "<li><a href=\"#Page=".($counter)."\" onClick='changePagination(".($counter).");'>$counter</a></li>";     
               }
               $pagination.= "..";
               $pagination.= "<li><a href=\"#Page=".($lpm1)."\" onClick='changePagination(".($lpm1).");'>$lpm1</a></li>";
               $pagination.= "<li><a href=\"#Page=".($lastpage)."\" onClick='changePagination(".($lastpage).");'>$lastpage</a></li>";   
           }
           else
           {
               $pagination.= "<li><a href=\"#Page=\"1\"\" onClick='changePagination(1);'>1</a></li>";
               $pagination.= "<li><a href=\"#Page=\"2\"\" onClick='changePagination(2);'>2</a></li>";
               $pagination.= "..";
               for($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
               {
                   if($counter == $page)
                        $pagination.= "<li><span class='current'>$counter</span></li>";
                   else
                        $pagination.= "<li><a href=\"#Page=".($counter)."\" onClick='changePagination(".($counter).");'>$counter</a></li>";     
               }
           }
        }
        if($page < $counter - 1)
            $pagination.= "<li><a href=\"#Page=".($next)."\" onClick='changePagination(".($next).");'>Next &raquo;</a></li>";
        else
            $pagination.= "<li><span class='disabled'>Next &raquo;</span></li>";

        $pagination.= "</ul>";       
    }

if(isset($_POST['pageId']) && !empty($_POST['pageId']))
{
    $id=$_POST['pageId'];
}
else
{
    $id='0';
}
$query="SELECT file_name,course FROM uploads WHERE instructor='$fname' AND (course='$course'  OR course='$course2' OR course='$course3') LIMIT ".mysqli_real_escape_string($link,$start).",$recordsPerPage";
$res    =   mysqli_query($link,$query);
$count  =   mysqli_num_rows($res);
$HTML='';
if($count > 0)
{
    while($row=mysqli_fetch_array($res))
    {
        $file_name = $row['file_name'];
        $cos = $row['course'];

echo "<li class='list-group-item con'><span class='glyphicon glyphicon-file'></span>$file_name</li> 
<li><span class='badge hiit_color white_color btn-primary'>$cos</span></li>";

    }
}
else
{
   // $HTML='No Data Found';
   echo "No Data Found";
}
//echo $HTML;
echo $pagination;

?>