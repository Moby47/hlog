<?php

require("../includes/downloads.php");
session_start();

$course=$_SESSION['course'];
$course2=$_SESSION['course2'];
$course3=$_SESSION['course3'];
$fname=$_SESSION['fname'];

$search=$_POST['id'];


if(empty($search)){
	echo "<div class='alert alert-info text-center  alert_margin  margin_up'>
						 
						   Insert File Name...
						</div>";
}else{

$get="SELECT file_name FROM uploads where file_name like '%$search%'AND instructor='$fname' AND (course='$course'  OR course='$course2' OR course='$course3') ";

$run=mysqli_query($link, $get);

if (mysqli_num_rows($run) < 1){

    echo "<div class='alert alert-danger text-center  alert_margin  margin_up'>
						  
						   No File Found!
						</div>";
}else { 

while ($row=mysqli_fetch_array($run)){

$file_name = $row['file_name'];

echo "<li class='list-group-item con'> <span class='glyphicon glyphicon-file'></span>   $file_name</li> ";

}//while end

}//if end

}//if empty