<?php
require("../includes/downloads.php");


$q="SELECT status FROM users WHERE status='student' AND verification!='unverified'";

$qq=mysqli_query($link,$q);

$num=mysqli_num_rows($qq);

echo "$num";

?>