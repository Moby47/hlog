<?php

require("../includes/downloads.php");
session_start();

$search=$_POST['id'];

if(empty($search)){
	echo "<div class='alert alert-info text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						   Search a Word...
						</div>";
}else{

$get="SELECT * FROM forum WHERE message like '%$search%' ";

$run=mysqli_query($link, $get);

if (mysqli_num_rows($run) < 1){

    echo "<div class='alert alert-danger text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						   No Comment Found!
						</div>";
}else { 

while ($row=mysqli_fetch_array($run)){

$username = $row['username'];
$status = $row['status'];
$time = $row['moment'];
$message = $row['message'];

$refined=htmlentities($message);
echo " <div class='alert alert-info text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						  $username <i class='badge'>$status</i> <i class='badge'>$time</i><br>
						  $message
						</div>";
}//while end

}//if end

}//if em