<?php
require("../includes/downloads.php");
session_start();


$fname=$_SESSION['fname'];


$query="SELECT course FROM uploads WHERE instructor='$fname' ";
$res    = mysqli_query($link,$query);
$count  = mysqli_num_rows($res);

echo "$count";

?>