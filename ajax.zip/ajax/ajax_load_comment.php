<?php

require("../includes/downloads.php");
session_start();


$get="SELECT * FROM forum ORDER BY forum_id DESC";

$run=mysqli_query($link, $get);

if (!$run){

    echo "Unable To Load Messages...Contact Admin";
}else { 

while ($row=mysqli_fetch_array($run)){

$username = $row['username'];
$status = $row['status'];
$time = $row['moment'];
$message = $row['message'];

$refined=htmlentities($message);

echo " <div class='direct-chat-msg'>
                      <div class='direct-chat-info clearfix'>
                        <span class='direct-chat-name pull-left'>$username</span>
                        <span class='direct-chat-timestamp pull-right'>$time</span>
                      </div>
                      <!-- /.direct-chat-info -->
                      <img class='direct-chat-img' src='images/user.png' alt='user image'><!-- /.direct-chat-img -->
                      <div class='direct-chat-text'>
                        $refined
                      </div>
                      <!-- /.direct-chat-text -->
                    </div>";

}//while end

}//if end

?>