<?php
require("../includes/downloads.php");
session_start();


$fname=$_SESSION['fname'];

$error=array();

$valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp' , 'iso' , 'zip' , 'rar' , 'php' , 'html' , 'txt' , 'css' , 'mp4' , 'zip' , 'avi'); // valid extensions
$path = '../files/'; // upload directory

if(isset($_FILES['image']))
{
	$img = $_FILES['image']['name'];
	$tmp = $_FILES['image']['tmp_name'];
    
if(empty($_POST['title'])){
$error[]="Enter File Title";
}else{
$title=mysqli_real_escape_string($link, trim($_POST['title']));
}

if(empty($_POST['cos'])){
$error[]="Select a Course";
}else{
$course=mysqli_real_escape_string($link, trim($_POST['cos']));
}

   if(!empty($error)){
  foreach ($error as $err){
    echo "<div class='alert alert-warning text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						   $err
						</div>";
}
}else{

// get uploaded file's extension
	$ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
	
	// can upload same image using rand function
	$final_image = rand(1000,1000000).$img;
	//echo $final_image;
	// check's valid format
	if(in_array($ext, $valid_extensions)) {					
		$path = $path.strtolower($final_image);	
			
//insert here
$insert= "INSERT INTO uploads (`file_name`, `file`, `course`, `instructor`) 
values ('$title','$final_image','$course','$fname')";

$insert_f = mysqli_query($link, $insert);

if($insert_f && move_uploaded_file($tmp,$path)){
    echo "<div class='alert alert-success text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						   Upload Successful!
						</div>";
}else{
echo "Upload Failed";
}



	} else {
		echo 'invalid';
    
	}

}//if empty end

		
	
}//main if



?>