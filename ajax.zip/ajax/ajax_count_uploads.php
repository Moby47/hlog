<?php
require("../includes/downloads.php");
session_start();


$course=$_SESSION['course'];
$course2=$_SESSION['course2'];
$course3=$_SESSION['course3'];

$query="SELECT * FROM uploads WHERE course='$course' OR course='$course2' OR course='$course3' ";
$res    = mysqli_query($link,$query);
$count  = mysqli_num_rows($res);

echo "$count";

?>