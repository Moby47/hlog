<?php

require("../includes/downloads.php");
session_start();

$lname = $_SESSION['lname'];
$stat = $_SESSION['status'];

if(empty($_POST['comment']) or $_POST['comment']==""){
echo "<script> alert('Type a Comment');</script>";
}else{
$comment=mysqli_real_escape_string($link, trim($_POST['comment']));


$send="INSERT INTO forum (`username`, `status`, `moment`, `message`) 
VALUES ('$lname', '$stat', NOW(), '$comment')";

$query=mysqli_query($link,$send);

if($query){

echo  "Sent!";
}else{

  echo "Message Failed, Contact Admin";    
}

}//if em
?>