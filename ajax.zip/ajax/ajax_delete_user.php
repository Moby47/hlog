<?php
require("../includes/downloads.php");
session_start();


//get the variable
$userid=$_POST['id'];

//echo $userid;

$do="DELETE FROM users WHERE user_id=$userid LIMIT 1";
	$q=mysqli_query($link,$do);
	if(mysqli_affected_rows($link)==1){
		echo "<div class='alert alert-success text-center alert-dismissable alert_margin margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						   User Deleted Successfully!
						</div>";
}else{

echo "<div class='alert alert-success text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						    User Deleted Successfully!
						</div>";
}

















?>
