<?php
require("../includes/downloads.php");



$query="SELECT user_id,fname,lname,email,course,course2,course3,status FROM users WHERE status!='admin' and verification='verified'";
$res    = mysqli_query($link,$query);
$count  = mysqli_num_rows($res);
$page = (int) (!isset($_REQUEST['pageId']) ? 1 :$_REQUEST['pageId']);
$page = ($page == 0 ? 1 : $page);
$recordsPerPage = 3;
$start = ($page-1) * $recordsPerPage;
$adjacents = "2";

$prev = $page - 1;
$next = $page + 1;
$lastpage = ceil($count/$recordsPerPage);
$lpm1 = $lastpage - 1;   
$pagination = "";
if($lastpage > 1)
    {   
        $pagination .= "<ul class='pagination pagination-md'>";
        if ($page > 1)
            $pagination.= "<li><a href=\"#Page=".($prev)."\" onClick='changePagination(".($prev).");'>&laquo; Previous&nbsp;&nbsp;</a></li>";
        else
            $pagination.= "<li><span class='disabled'>&laquo; Previous&nbsp;&nbsp;</span></li>";   
        if ($lastpage < 7 + ($adjacents * 2))
        {   
            for ($counter = 1; $counter <= $lastpage; $counter++)
            {
                if ($counter == $page)
                    $pagination.= "<li><span class='current'>$counter</span></li>";
                else
                    $pagination.= "<li><a href=\"#Page=".($counter)."\" onClick='changePagination(".($counter).");'>$counter</a></li>";     

            }
        }   

        elseif($lastpage > 5 + ($adjacents * 2))
        {
            if($page < 1 + ($adjacents * 2))
            {
                for($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
                {
                    if($counter == $page)
                        $pagination.= "<li><span class='current'>$counter</span></li>";
                    else
                        $pagination.= "<li><a href=\"#Page=".($counter)."\" onClick='changePagination(".($counter).");'>$counter</a></li>";     
                }
                $pagination.= "...";
                $pagination.= "<li><a href=\"#Page=".($lpm1)."\" onClick='changePagination(".($lpm1).");'>$lpm1</a></li>";
                $pagination.= "<li><a href=\"#Page=".($lastpage)."\" onClick='changePagination(".($lastpage).");'>$lastpage</a></li>";   

           }
           elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
           {
               $pagination.= "<li><a href=\"#Page=\"1\"\" onClick='changePagination(1);'>1</a></li>";
               $pagination.= "<li><a href=\"#Page=\"2\"\" onClick='changePagination(2);'>2</a></li>";
               $pagination.= "...";
               for($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
               {
                   if($counter == $page)
                       $pagination.= "<li><span class='current'>$counter</span></li>";
                   else
                       $pagination.= "<li><a href=\"#Page=".($counter)."\" onClick='changePagination(".($counter).");'>$counter</a></li>";     
               }
               $pagination.= "..";
               $pagination.= "<li><a href=\"#Page=".($lpm1)."\" onClick='changePagination(".($lpm1).");'>$lpm1</a></li>";
               $pagination.= "<li><a href=\"#Page=".($lastpage)."\" onClick='changePagination(".($lastpage).");'>$lastpage</a></li>";   
           }
           else
           {
               $pagination.= "<li><a href=\"#Page=\"1\"\" onClick='changePagination(1);'>1</a></li>";
               $pagination.= "<li><a href=\"#Page=\"2\"\" onClick='changePagination(2);'>2</a></li>";
               $pagination.= "..";
               for($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
               {
                   if($counter == $page)
                        $pagination.= "<li><span class='current'>$counter</span></li>";
                   else
                        $pagination.= "<li><a href=\"#Page=".($counter)."\" onClick='changePagination(".($counter).");'>$counter</a></li>";     
               }
           }
        }
        if($page < $counter - 1)
            $pagination.= "<li><a href=\"#Page=".($next)."\" onClick='changePagination(".($next).");'>Next &raquo;</a></li>";
        else
            $pagination.= "<li><span class='disabled'>Next &raquo;</span></li>";

        $pagination.= "</ul>";       
    }

if(isset($_POST['pageId']) && !empty($_POST['pageId']))
{
    $id=$_POST['pageId'];
}
else
{
    $id='0';
}
$query="SELECT user_id,fname,lname,email,course,course2,course3,status FROM users WHERE status!='admin' and verification='verified' LIMIT ".mysqli_real_escape_string($link,$start).",$recordsPerPage";
$res    =   mysqli_query($link,$query);
$count  =   mysqli_num_rows($res);
$HTML='';
if($count > 0){
    echo "
    <div class='table-responsive'>
    <table class='table table-hover table-bordered table-striped  white margin_up'>
<tr>
<th>FIRST NAME</th>
<th>LAST NAME</th>
<th>EMAIL</th>
<th>COURSE</th>
<th>COURSE2</th>
<th>COURSE3</th>
<th>USER</th>
<th>DELETE</th>
</tr>";
    while($row=mysqli_fetch_array($res)) {
       $id=$row['user_id'];
$fname = $row['fname'];
$lname = $row['lname'];
$email = $row['email'];
$course = $row['course'];
$course2 = $row['course2'];
$course3 = $row['course3'];
$user = $row['status'];

echo "
<tr>
<td>$fname</td>
<td>$lname</td>
<td>$email</td>
<td>$course</td>
<td>$course2</td>
<td>$course3</td>
<td>$user</td>
<td><a  href='#' id='$id' class='btn btn-danger del'><span class='glyphicon glyphicon-trash' aria-hidden='true'></span></a></td>
</tr>
";
    }//while end
    echo "</table>
    </div>";

}else{
   // $HTML='No Data Found';
   echo "<span class='alert alert-primary'>No Data Found</span>";
}
//echo $HTML;
echo $pagination;

?>



































<script>

$(function(){

	$(".del").click(function(){

    let element=$(this);
    let userid=element.attr("id");
    let info='id=' + userid;
    //alert(info);
if (confirm("Delete This User?")){

 $.ajax({
            url: 'ajax/ajax_delete_user.php',
            type: 'post',
            data: info,


            success: function(data){
            $(".deleted").html(data);
  $(".count1").load("ajax/ajax_count_instructors.php");
 $(".count2").load("ajax/ajax_count_students.php");
            }//success end
        });//ajax end

    $(this).parent().parent().fadeOut(300, function(){
        $(this).remove();
    });


}//if confirm end

})//del click end

})//func end




</script>