<?php
require("../includes/downloads.php");
session_start();


//get the variable
$userid=$_POST['id'];

//echo $userid;

		//change the status from unverified
 $query="UPDATE users SET verification='verified' WHERE user_id='$userid'";
 $r=mysqli_query($link,$query);

	if($r){
echo "<div class='alert alert-success text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						   User Approved!
						</div>";

}else{
echo "<div class='alert alert-success text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						  Not Approved!
						</div>";
    }//if end














?>
