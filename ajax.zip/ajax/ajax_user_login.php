<?php
require("../includes/downloads.php");
session_start();

$mail=mysqli_real_escape_string($link, trim($_POST['user_mail']));
$pass=mysqli_real_escape_string($link, trim($_POST['user_pass']));
$unv="unverified";

//query
$detail = "SELECT * FROM users where email='$mail' and password='$pass' and verification!='$unv'";

//run query
$r=mysqli_query($link,$detail);

if(mysqli_num_rows($r)==1){

	$row=mysqli_fetch_array($r,MYSQLI_ASSOC);
	$_SESSION['id']=$row['user_id'];
    $_SESSION['fname']=$row['fname'];
     $_SESSION['lname']=$row['lname'];
	$_SESSION['email']=$row['email'];
	$_SESSION['password']=$row['password'];
     $_SESSION['course']=$row['course'];
	  $_SESSION['course2']=$row['course2'];
	   $_SESSION['course3']=$row['course3'];
      $_SESSION['status']=$row['status'];
	  $_SESSION['date_reg']=$row['date_reg'];

$user=$_SESSION['status'];

echo "$user";

//if end
}else{
	echo "<div class='alert alert-danger text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						   Invalid Input Or Unverified User
						</div>";
}
//post end


?>