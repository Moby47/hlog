-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 12, 2018 at 11:23 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `downloads`
--

-- --------------------------------------------------------

--
-- Table structure for table `forum`
--

CREATE TABLE IF NOT EXISTS `forum` (
  `forum_id` int(15) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL,
  `status` varchar(12) NOT NULL,
  `moment` datetime NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`forum_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `forum`
--

INSERT INTO `forum` (`forum_id`, `username`, `status`, `moment`, `message`) VALUES
(1, 'Shobajo', 'admin', '2018-01-12 10:34:59', 'I am the Admin'),
(2, 'Onyemaobi', 'instructor', '2018-01-12 10:51:34', 'Hello, i am an Instructor'),
(3, 'Shobajo', 'student', '2018-01-12 11:07:48', 'Hi, am a Student');

-- --------------------------------------------------------

--
-- Table structure for table `misc`
--

CREATE TABLE IF NOT EXISTS `misc` (
  `misc_id` int(5) NOT NULL AUTO_INCREMENT,
  `courses` varchar(60) NOT NULL,
  PRIMARY KEY (`misc_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `misc`
--

INSERT INTO `misc` (`misc_id`, `courses`) VALUES
(1, 'CCNA'),
(2, 'Web Design'),
(3, 'A+');

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE IF NOT EXISTS `uploads` (
  `file_id` int(13) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(100) NOT NULL,
  `file` text NOT NULL,
  `course` varchar(60) NOT NULL,
  `instructor` varchar(20) NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `uploads`
--

INSERT INTO `uploads` (`file_id`, `file_name`, `file`, `course`, `instructor`) VALUES
(1, 'hiit logo', '379070hiit.png', 'Web Design', 'Henry'),
(2, 'user icon', '487512user.png', 'CCNA', 'Henry'),
(3, 'Bootstrap Video Tutorials', '954300Bootstrap Tutorials.zip', 'Web Design', 'Henry'),
(4, 'Bootstrap Video Tutorials Again', '654063Bootstrap Tutorials.zip', 'Web Design', 'Henry');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(30) NOT NULL,
  `course` varchar(50) NOT NULL,
  `course2` varchar(50) NOT NULL,
  `course3` varchar(50) NOT NULL,
  `status` varchar(15) NOT NULL,
  `verification` varchar(16) NOT NULL,
  `date_reg` date NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `fname`, `lname`, `email`, `password`, `course`, `course2`, `course3`, `status`, `verification`, `date_reg`) VALUES
(1, 'Segun', 'Shobajo', 'bmhic@hiitplc.com', 'admin', '', '', '', 'admin', 'verified', '2018-01-12'),
(2, 'Henry', 'Onyemaobi', 'henryonyemaobi@gmail.com', 'instructor', 'Web Design', 'CCNA', 'A+', 'instructor', 'verified', '2018-01-12'),
(3, 'Taye', 'Shobajo', 'tayeshobajo@yahoo.com', 'student', 'CCNA', 'Web Design', 'A+', 'student', 'verified', '2018-01-12');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
