<?php

//establish db connection
$link=mysqli_connect("localhost","root","","downloads");

if($link){
    echo "";
}else{
    echo "<div class='alert alert-danger alert-dismissable alert_margin'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						   Fatal Error, Contact Developer!
						</div>";
    die();
}

?>