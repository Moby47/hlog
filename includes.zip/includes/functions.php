<?php
require("downloads.php");


/*
//show files uploaded by instructor
function instructor_files_uploaded(){

global $link;

$course=$_SESSION['course'];

$get="SELECT * FROM uploads WHERE course='$course'";
// WHERE course='$course'
$run=mysqli_query($link,$get);

while ($row=mysqli_fetch_array($run)){

$file_name = $row['file_name'];

echo " <p class='list-group-item'>$file_name</p>";

}//while end

}//func end


*/








//logut button

function logout(){

if(isset($_POST['logout'])){
	
	session_destroy();
	//header('location: index.php');
	echo "<script>window.open('index.php','_self')</script>";
//echo "<script> location.reload();</script>";

}
	//function end
}



function redirect_unauthorised(){

// check login
if(!isset($_SESSION['email'])){
    header('location:index.php');
}
	//func end
}




function only_admin(){

// check login
if($_SESSION['status']!=='admin'){
    header('location:index.php');
}
	//func end
}

function only_student(){

// check login
if($_SESSION['status']!=='student'){
    header('location:index.php');
}
	//func end
}



function only_instructor(){

// check login
if($_SESSION['status']!=='instructor'){
    header('location:index.php');
}
	//func end
}



//delete users function
/*
function delete_user(){

	global $link;

if(isset($_GET['delete']) && isset($_GET['name'])){

$id =$_GET['delete'];
$lname =$_GET['name'];

$do="DELETE FROM users WHERE user_id=$id LIMIT 1";
	$q=mysqli_query($link,$do);
	if(mysqli_affected_rows($link)==1){
		echo "<div class='alert alert-success text-center alert-dismissable alert_margin margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						   User $lname Deleted Successfully!
						</div>";
}else{

echo "<div class='alert alert-danger text-center alert-dismissable alert_margin  margin_up'>
						  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						   User $lname Has been Deleted Already!
						</div>";
}



}//if end

}//func end

*/







//display all courses

function display_courses(){

global $link;

	$get="SELECT courses FROM misc";

$run=mysqli_query($link,$get);

while ($row=mysqli_fetch_array($run)){

$cos = $row['courses'];

echo "<option value='$cos'>$cos</option>";

}//while end
}//func end

















/*





//function to redirect students

function redirect_students(){

if($_SESSION['status'] == "student"){

   header('location:student.php');
   exit();

}else{
   echo "";

}

	//func end
}


*/














?>